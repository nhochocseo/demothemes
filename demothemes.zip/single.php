<?php get_header(); ?>
<div id="main-content" class="row"><div id="content" class="col-md-8">
	<?php echo $post->post_content; ?>
</div>
<?php get_footer(); ?>