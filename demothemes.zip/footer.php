</div><!-- End Wraper -->
	<div class="footer">
		<div class="foot-container">
			<div class="col-md-6 foot-content pull-left">&copy : <?php bloginfo( 'sitename' ); ?></div>
			<div class="col-md-6 foot-content pull-right"><?php echo date('Y'); ?></div>
		</div>
	</div>
</div> <!-- End Container -->
<script type='text/javascript' src="<?php echo get_template_directory_uri(); ?>/core/js/jquery-2.1.3.min.js"></script>
<script type='text/javascript' src="<?php echo get_template_directory_uri(); ?>/bootstrap/js/bootstrap.min.js"></script>
<!-- <script type='text/javascript' src='<?php echo get_template_directory_uri(); ?>/core/js/core-ui.js?ver=4.4.2'></script> -->
<?php wp_footer(); ?>
</body>
</html>