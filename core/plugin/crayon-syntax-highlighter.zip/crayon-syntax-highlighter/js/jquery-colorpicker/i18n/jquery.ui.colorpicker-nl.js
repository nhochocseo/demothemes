jQuery(function($) {
	$.colorpicker.regional['nl'] = {
		ok:				'OK',
		cancel:			'Annuleren',
		none:			'Geen',
		button:			'Kleur',
		title:			'Kies een kleur',
		transparent:	'Transparant',
		hsvH:			'H',
		hsvS:			'S',
		hsvV:			'V',
		rgbR:			'R',
		rgbG:			'G',
		rgbB:			'B',
		labL:			'L',
		labA:			'a',
		labB:			'b',
		hslH:			'H',
		hslS:			'S',
		hslL:			'L',
		cmykC:			'C',
		cmykM:			'M',
		cmykY:			'Y',
		cmykK:			'K',
		alphaA:			'A'
	};
});